from django.apps import AppConfig


class ItineraryConfig(AppConfig):
    name = 'itinerary'
